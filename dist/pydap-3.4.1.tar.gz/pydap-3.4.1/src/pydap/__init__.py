'''
Declare the namespace ``pydap`` here.
'''
__import__('pkg_resources').declare_namespace(__name__)

__version__ = '3.4.1'
